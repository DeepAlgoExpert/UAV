
#ifndef timer_H
#define timer_H

void StartTimer(void);
double StopTimer(void);
double PrintTimer(void);

#endif
